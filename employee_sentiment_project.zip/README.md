# Employee Sentiment Analysis Project

This repository contains the complete solution for the Employee Sentiment Analysis assignment.
